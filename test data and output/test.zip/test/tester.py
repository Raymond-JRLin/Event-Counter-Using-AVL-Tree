#!/usr/bin/env python
import random
import subprocess
import math
import sys
import threading

localModel = {}

#we're going to test IDs in range [0 1024)
maxID = 1024

args = ["./bbst", "sample.txt"]
if len(sys.argv)>1:
    args = sys.argv[1:]

testProgram = subprocess.Popen(args, stdin = subprocess.PIPE, stdout = subprocess.PIPE, universal_newlines = True,bufsize=1)

for i in range(maxID):
    localModel[i] = 0

####################################################################
print("#########File Load#########")
####################################################################

failed = False

infile = open(args[len(args)-1], 'r');
firstline = True
for line in infile:
    if firstline:
        firstline = False
    else:
        vals = line.split()
        localModel[int(vals[0])] = int(vals[1])
        testProgram.stdin.write("count "+vals[0]+"\n")
        result = testProgram.stdout.readline()
        if (int(result) != int(vals[1])):
            print("Error: expected "+vals[1]+", got "+result)
            failed = True
infile.close();

if not failed:
    print("SUCCESS: initial counts matched file contents")

####################################################################
print("#########Performing Random Operations#########")
####################################################################

failed = 0
instructionCount = 32768

for i in range(instructionCount):
    r = random.randint(0,2)
    ID = random.randint(0,maxID-1);
    m = random.randint(1,5);
    if r == 0:
        command = "increase "+str(ID)+" "+str(m)
        localModel[ID] = localModel[ID] + m
    else:
        command = "reduce "+str(ID)+" "+str(m)
        localModel[ID] = localModel[ID] - m
        if localModel[ID] <= 0:
            localModel[ID]=0
    testProgram.stdin.write(command+'\n');
    count = int(testProgram.stdout.readline())
    if count != localModel[ID]:
        print("ERROR ["+command+"] expected "+
              str(localModel[ID]) + ", got "+str(count))
        failed = failed+1
    #confirm height has not been changed
    testProgram.stdin.write('height\n')
    height = int(testProgram.stdout.readline())
    if (height > math.ceil(1.44*maxID)):
        print("ERROR: Height should not be greater than "+str(math.ceil(1.44*maxID))+", but was "+str(height))

    #print(command)

if failed > 0:
    print("Failed with "+str(failed)+" mistakes")
else:
    print("SUCCESS: Succesful counts for all keys in range [0, "+str(maxID)+")")

####################################################################
print("########Testing for deletion of unused IDs#########")
####################################################################

tmpCount = 65536

for i in range(maxID,tmpCount):
    testProgram.stdin.write("increase "+str(ID)+" 1\n")
    count = int(testProgram.stdout.readline())
    testProgram.stdin.write("reduce "+str(ID)+" 1\n")
    count = int(testProgram.stdout.readline())

testProgram.stdin.write('height\n')
height = int(testProgram.stdout.readline())
if (height > math.ceil(1.44*maxID)):
    print("ERROR: Height should not be greater than "+str(math.ceil(1.44*maxID)))
else:
    print("SUCCESS: Final Height = "+str(height))

####################################################################
print("#########Testing Height During Random Deletion#########")
####################################################################

failed = False;

for i in range(0,maxID):
    keyList = list(localModel.keys())
    keyIndex = random.randint(0,len(keyList)-1)
    key = keyList[keyIndex]
    testProgram.stdin.write("reduce "+str(key)+" "+str(localModel[key])+'\n')
    count = int(testProgram.stdout.readline())
    del localModel[key]
    testProgram.stdin.write('height\n')
    height = int(testProgram.stdout.readline())
    maxHeight = math.ceil(1.44*len(list(localModel.keys())))
    if (height > maxHeight):
        print("ERROR: Height should not be greater than "+str(math.ceil(1.44*maxHeight))+", but was "+str(height))
        failed = True
        
if not failed:
    sys.stdout.write("SUCCESS: ")
print("Height after all deletions: "+str(height))

#####################################################################
print("#########Testing Height During Random Rebuild#########");
#####################################################################

instructionCount = 32768

failed = False

for i in range(instructionCount):
    ID = random.randint(0,maxID-1);
    m = random.randint(1,5);
    command = "increase "+str(ID)+" "+str(m)
    if ID in localModel:
        localModel[ID] = localModel[ID] + m
    else:
        localModel[ID] = m
    testProgram.stdin.write(command+'\n');
    count = int(testProgram.stdout.readline())
    #confirm height is okay
    testProgram.stdin.write('height\n')
    height = int(testProgram.stdout.readline())
    maxHeight = math.ceil(1.44*len(list(localModel.keys())))
    if (height > maxHeight):
        print("ERROR: Height should not be greater than "+str(math.ceil(1.44*maxHeight))+", but was "+str(height))
        failed = True

if not failed:
    sys.stdout.write("SUCCESS: ")
print("Final Height: "+str(height))


testProgram.stdin.write('quit\n')

